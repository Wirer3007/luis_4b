import {View, Text, TextInput, Image} from 'react-native';
import Estilos from "../Telas/Estilos";
import logo from '../sl.webp';

import Drag from '../components/dragDrop';
export default function Home({route}){
 
 let id = 0;
 if  (route.params != null) {
    id = route.params.id;
    console.log(id);
 }
  
  return(
    <View>

    <View style={Estilos.homE}>

    <Text style={Estilos.tituloS}> Bem Vindo A Pagina inicial</Text>
    <Image source={logo} style={Estilos.logO}/>

    </View>

    { 
      id == 2 && 
      <Drag/>
    
    }
    { 
      id == 1 && 
      <Drag/>
    
    }

    <View style={Estilos.blocO}>
    </View>
    
    </View>
  );
}