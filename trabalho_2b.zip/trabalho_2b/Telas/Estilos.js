import { StyleSheet } from 'react-native';

export default StyleSheet.create({

    menuT: {width: '100%', height: '100%',   flexDirection:'row', flexWrap:'wrap', backgroundColor: 'red', flex: 1},
    safeAreaViewContainer: { backgroundColor: '#000', flex: 1, padding: 8},
    tituloS:{fontSize: 30, color: 'black', fontWeight: 'bold', textAlign: 'center'},
    descriS:{fontSize: 30, color: '#140E0E', textAlign: 'center'},
    carD: {flex: 1, borderWidth: 3, borderColor: '#DFD4FF', borderRadius: 18, padding: 18, marginVertical: 15, marginHorizontal: 10,flexDirection:'row'},
    imageM: {width: 300, height: 300, resizeMode: 'contain', alignSelf: 'center', marginTop: 15, borderRadius: 15,},
    listA: {flexGrow: 0,},
    textI:{ backgroundColor: '#DFD4FF',  padding: 12, borderRadius: 12, marginBottom: 20,},
    textI2:{ backgroundColor: '#DFD4FF',  padding: 20, borderRadius: 50, marginBottom: 5,},
    petS:{textAlign: 'rigth', justifyContent: 'space-between', fontWeight: 'bold', fontSize: 20, letterSpacing: 1,},
    seleC:{flexDirection:'row', paddingLeft:20, justifyContent: 'space-between'},
    homE:{justifyContent: 'center', alignItems: 'center'},
    logO:{marginTop: 200},
    blocO:{backgroundColor: '#3B3B3B', marginTop: 280, width: 400, height: 100},

}); 
export const drawerStyles = {
  headerStyle: {
    backgroundColor : '#DFD4FF'
  },
  headerTintColor: '#fff',
  headerTitleStyle: {
    fontWeight: 'bold'

  },
  drawerStyle: {
    backgroundColor: '#DFD4FF',
    fontWeight: 'bold'
  },
  drawerActiveTintColor: '#6232FA',
  drawerInactiveTintColor: 'white',
  drawerLabelStyle: {
    fontWeight: 'bold'
  }
}