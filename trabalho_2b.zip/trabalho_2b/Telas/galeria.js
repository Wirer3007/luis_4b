import React, { useState } from 'react';
import {View, Text, TextInput, SafeAreaView, FlatList, Image, StyleSheet} from 'react-native';
import Estilos from "../Telas/Estilos";

const Imagens = [
  { id: '1', nome: 'soshiro hoshina', caminho: require('../soshiro.png' ) },
  {id: '2', nome: 'ashiro', caminho: require('../soshi.png') }];

export default function Galeria() {

  const [busca, setBusca] = useState('');

  const filtro = Imagens.filter(item =>
    item.nome.toLowerCase().includes(busca.toLowerCase())
  );

  return (

    <View>

      <Text style={Estilos.tituloS}>Seja bem-vindo à galeria</Text>
      <Text style={Estilos.descriS}>Personagens disponíveis:</Text>

      <SafeAreaView>
        <TextInput placeholder="Buscar personagem" value={busca} onChangeText={setBusca} style={Estilos.textI}/>

        <FlatList
          data={filtro}
          keyExtractor={item => item.id}
          ListEmptyComponent={ <Text>Nenhuma imagem encontrada.</Text>}
          renderItem={({ item }) => (
            <View>
              <Image source={item.caminho} style={Estilos.imageM}/>
              <Text style={Estilos.descriS}>{item.nome}</Text>
            </View>
          )}
        />
      </SafeAreaView>
    </View>
  );
}