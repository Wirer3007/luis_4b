import {SafeAreaView, StatusBar } from 'react-native';
import Estilos from '../Telas/Estilos';
import {NavigationContainer} from '@react-navigation/native';
import { createDrawerNavigator} from '@react-navigation/drawer';
import Galeria from '../Telas/galeria';
import Select from '../Telas/select';
import Home from '../Telas/home'
import {drawerStyles} from  '../Telas/Estilos'
import {Ionicons} from '@expo/vector-icons';
import{useEffect, useState} from "react";
import Drag from '../components/dragDrop';



const Drawer = createDrawerNavigator();

export default function Menu() {
  return (
   <>
    <StatusBar barStyle="light-content" 
     backgroundColor="#000"/>
    <SafeAreaView style={Estilos.menuT}>
    <NavigationContainer>
    <Drawer.Navigator
    initialRouteName="Home"
    screenOptions={drawerStyles}
    
    >
     <Drawer.Screen name="Home" component={Home}
      options={{
          drawerIcon: ({color, size}) => (
            <Ionicons name="home-outline" color={color} size={size}/>
          )}}/>
   
    <Drawer.Screen name="Galeria" component={Galeria}
     options={{
          drawerIcon: ({color, size}) => (
            <Ionicons name="image-outline" color={color} size={size}/>
          )

      }}/>
      <Drawer.Screen name="Select" component={Select}
     options={{
          drawerIcon: ({color, size}) => (
           <Ionicons name="download-outline" size={24} color={color} />
          )

      }}/>

     

      
    </Drawer.Navigator>
    </NavigationContainer>
     
    </SafeAreaView>
   </>
  );
}


