import React from 'react';
import {View, Text, ScrollView, Image, TextInput, Button, TouchableOpacity, SafeAreaView, FlatList, Alert} from 'react-native';
import Estilos from '../Telas/Estilos';
import {Divider} from 'react-native-paper';
import {Ionicons} from '@expo/vector-icons';
import FontAwesome from '@expo/vector-icons/FontAwesome';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { useState } from 'react';


const Pets = [
  {id: '1', nome: ('soshiro hoshina')},
  {id:'2', nome: ('ashiro')}];

export default function Select ({ navigation }) {

  const [busca, setBusca] = useState('');

  const filtro = Pets.filter(item =>
    item.nome.toLowerCase().includes(busca.toLowerCase())
  );

  function navegarHome(id) {
    navigation.navigate('Home', {
      id: id
    })
  }

  function alertinha(){
    Alert.alert('Dowload Character...')
  }


  return(

     <View>

      <Text style={Estilos.tituloS}>Seja bem-vindo ao Select</Text>
      <Text style={Estilos.descriS}>Personagens disponíveis para selecionar:</Text>

      <SafeAreaView>
        <TextInput placeholder="Buscar personagem" value={busca} onChangeText={setBusca} style={Estilos.textI2}/>

        <FlatList
          data={filtro}
          keyExtractor={item => item.id}
          ListEmptyComponent={ <Text>Nenhum personagem encontrado</Text>}
          renderItem={({ item }) => (
            <View style={Estilos.carD}>
              <Text style={Estilos.petS}>{item.nome}</Text>
              
              <TouchableOpacity style={Estilos.seleC} onPress={() => navegarHome(item.id)}>
              <Icon name="pets" size={30} color="#000" />
              </TouchableOpacity>

              <TouchableOpacity style={Estilos.seleC} onPress={alertinha}>
              <Icon name="download" size={30} color="#000" />
              </TouchableOpacity>

            </View>
          )}
        />
      </SafeAreaView>
    </View>
     


    );
}