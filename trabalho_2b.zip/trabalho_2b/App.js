import { StyleSheet, Text, View, StatusBar} from 'react-native';
import {useState, useEffect} from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Animacao from './components/animation';
import Cadastro from './login/cadastro';
import Estilo from './login/Estilos'
import Login from './login/login';
import {Ionicons} from '@expo/vector-icons';
import Autenticador from './components/authenticator';
import Menu from './Telas/menu';
import Drag from './components/dragDrop';

export default function App() {


    const [telaLogin, setTelaLogin] = useState(true);
    const [loginok, setLoginOk]  = useState (false);
    const [liberado, setLiberado] = useState(false);
    const [downloadOk, setDownloadOk] = useState(false);
    const [animacaoAtiva, setAnimacaoAtiva] = useState(false);
    
    if (liberado) {
      return <Menu
      downloadOk={downloadOk}
      setDownloadOk={setDownloadOk}
      animacaoAtiva={animacaoAtiva}
      setAnimacaoAtiva={setAnimacaoAtiva}/>;
    }

    if (loginok) {
      return (
        <Autenticador setLiberado={setLiberado} />
      );
    }

    if (telaLogin) {
      return (
        <Login
          setTelaLogin={setTelaLogin}
          setLoginOk={setLoginOk}
        />
      );
}

return <Cadastro setTelaLogin={setTelaLogin} />;
}
