import { StyleSheet, Text, View, TouchableOpacity, Alert, } from 'react-native';
import {useState, useEffect} from 'react';
import * as LocalAuthentication from 'expo-local-authentication';

export default function Autenticador({setLoginOk, setLiberado}) {

  const [isAuthentic, setIsAuthentic] = useState(false);


  async function verifyAvaibleAuthentication(){

    const compatible = await LocalAuthentication.hasHardwareAsync();
    console.log(compatible);
  }

  useEffect(() => {

    verifyAvaibleAuthentication();

  });

  async function tiposCadastrados(){

    const cadastrados = await LocalAuthentication.isEnrolledAsync();
    
    if (cadastrados == null){

      console.log("nenhuma authenticação registrada no dispositivo");
      return;

    }

    const opcoesBiometria = await LocalAuthentication.authenticateAsync({
      promptMessage: "necessario biometria"
    });


     if (opcoesBiometria.success) {

      Alert.alert('Liberado')
      setLiberado(true);
  }

  }

  useEffect(() => {
  tiposCadastrados();
}, []);  
 
    return (
      <View>
        <Text>Autenticando...</Text>
      </View>
    );
}