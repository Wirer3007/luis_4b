import { useRef, useState, useEffect } from 'react';
import {View, Text, ScrollView, Image, PanResponder, ImageBackground, Animated, useWindowDimensions, StyleSheet  } from 'react-native';
import {Divider} from 'react-native-paper';
import {Ionicons} from '@expo/vector-icons';


//PanResponder - API do React Native usada para capturar gestures (arrastar, tocar etc).

export default function Drag() {
  const [posicao, setPosicao] = useState({ x: 60, y: 30 });
  const [isMoving, setIsMoving] = useState(false);
  let caminhoImagem = require('../soshi.png');

  if (isMoving == true){
    caminhoImagem = require('../soshi2.gif');
  }
  else{
    caminhoImagem = require('../soshi.png');
  }

  // Guarda a posição final após cada drag
  const ultimaPosicao = useRef({ x: 80, y: 350 }); //hook que armazena valores mutáveis sem causar re-renderização.

  //Guarda a posição final após cada arraste.
  //useRef NÃO causa re-render ao mudar.
  //ultimaPosicao.current é o valor armazenado.

  const panResponder = useRef( //Envolvido em useRef para garantir que o PanResponder só seja criado uma vez.
    PanResponder.create({
      onMoveShouldSetPanResponder: () => true, // Significa: "Qualquer movimento deve iniciar um gesto de arrastar."

      onPanResponderMove: (event, gesture) => { //"event" não é usado, mas é o primeiro parâmetro da arrow function
        setIsMoving(true);                                        //"gesture" contém dx -> deslocamento horizontal e dy -> deslocamento vertical
        setPosicao({ //Atualiza o estado para mover o quadrado na tela.
          x: ultimaPosicao.current.x + gesture.dx, //Calcula a nova posição com base na posição atual + o deslocamento horizontal
          y: ultimaPosicao.current.y + gesture.dy, //Calcula a nova posição com base na posição atual + o deslocamento vertical
        });
      },

      onPanResponderRelease: (event, gesture) => { //Quando o usuário solta o dedo, atualiza a posição final armazenada
        // Atualiza posição fixa final
        setIsMoving(false);
        ultimaPosicao.current = { //Apenas atualiza o valor interno do useRef, sem re-render.
          x: ultimaPosicao.current.x + gesture.dx,
          y: ultimaPosicao.current.y + gesture.dy,
        };
      },
    })
  ).current;

  return (
     

    <View style={{ flex: 1,}}>
      <View
        {...panResponder.panHandlers} //O spread (...) no React (e no JavaScript) serve para espalhar as propriedades de um objeto dentro de outro objeto. No nosso caso, significa: “Pegue todas as propriedades que existem dentro de panHandlers e coloque-as como props do <View>”.
        style={{
          position: "absolute",
          transform: [
            { translateX: posicao.x },
            { translateY: posicao.y },
          ],
        }}
      >

       <Image
    source={caminhoImagem}
    style={{
      
      width: 300,
      height: 300,
      resizeMode: 'contain',
    }}
  />

  

      
 

   


     
      </View>

    </View>

    
  );
}
