import React, { useRef, useEffect } from 'react';
import { View, StyleSheet, Animated, useWindowDimensions } from 'react-native';
import Estilos from '../Telas/Estilos';

export default function Animacao() {
  // 1. Pega a largura total da tela do celular dinamicamente
  const { width: larguraTela } = useWindowDimensions();
  
  const soshiro = require ("../soshi.png");
  // Tamanho da bolinha definido no estilo
  const TAMANHO_BOLINHA = 300;
  // O limite máximo que ela pode ir para a direita sem sumir da tela
  const limiteDireita = larguraTela - TAMANHO_BOLINHA;

  // 2. Inicializa o valor animado na posição zero (extrema esquerda)
  const posicaoX = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // 3. Define a sequência de ida e volta
    const sequenciaMovimento = Animated.sequence([
      // Vai para a direita
      Animated.timing(posicaoX, {
        toValue: limiteDireita,
        duration: 10000, // Tempo para ir (2 segundos)
        useNativeDriver: true,
      }),
      // Volta para a esquerda
      Animated.timing(posicaoX, {
        toValue: 0,
        duration: 10000, // Tempo para voltar (2 segundos)
        useNativeDriver: true,
      }),
    ]);

    // 4. Transforma a sequência em um loop infinito e inicia
    Animated.loop(sequenciaMovimento).start();
  }, [limiteDireita]); // Recalcula se a tela mudar de orientação (deitado/pé)

  return (
    <View style={styles.container}>
      <View style={styles.areaMovimento}>
      <Animated.Image
        source={soshiro}
        style={[
           {
             width: TAMANHO_BOLINHA,
            height: TAMANHO_BOLINHA,
            resizeMode: 'contain',
           },
           { transform: [{ translateX: posicaoX }] }
         ]}
    />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#111', // Fundo escuro para destacar
  },
  areaMovimento: {
    width: '100%',
  height: 200,
  justifyContent: 'center',
  marginTop: 500
  }
});
