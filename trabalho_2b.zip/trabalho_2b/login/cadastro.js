import Estilos from '../login/Estilos.js';
import { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, Alert, TouchableOpacity } from 'react-native';
import { initDB, adicionarPessoa, listarPessoas, deletarPessoa } from './database';
import PessoaItem from '../login/PessoaItem';
import { SafeAreaView, SafeAreaProvider } from 'react-native-safe-area-context';
import { createDrawerNavigator} from '@react-navigation/drawer'
import Login from '../login/login';


export default function Cadastro({ setTelaLogin }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [pessoas, setPessoas] = useState([]);

  async function carregarPessoas() {
    const lista = await listarPessoas();
    setPessoas(lista);
  };
  
  const prepararApp = async () => {
    await initDB();
    await carregarPessoas();
  };

  async function handleAdicionar() {
    if (!nome.trim() || !email.trim()) {
      Alert.alert('Erro', 'Preencha todos os campos');
      return;
    }
    await adicionarPessoa(nome, email);

    setTelaLogin(true);
  };

  async function handleDeletar(id) {
    await deletarPessoa(id);
    await carregarPessoas();
  };



  useEffect(() => {
    prepararApp();
  }, []);

  

  return (
    <SafeAreaProvider>
      <SafeAreaView style={Estilos.safeAreaViewContainer}>
        <Text style={Estilos.cabecarioT}>
          Bem vindo ao Cadastro 
        </Text>

        <View style={Estilos.camposCadastroContainer}>
          <TextInput
            placeholder="Nome"
            value={nome}
            onChangeText={setNome}
            style={Estilos.campoTexto}
          />
          <TextInput
            placeholder="senha"
            value={email}
            onChangeText={setEmail}
            secureTextEntry={true}
            style={Estilos.campoTexto}
          />
          <Button title="Adicionar" onPress={handleAdicionar} />
          <Text style={Estilos.descriCao}>Bem vindo a area de cadastros</Text>
          <Text style={Estilos.descriCao}>Ja tem uma conta?</Text>
          <TouchableOpacity onPress={() => setTelaLogin(true)}>

          <Text style={Estilos.descriCao2}>login</Text>
          
          </TouchableOpacity>
        </View>

        
      </SafeAreaView>
    </SafeAreaProvider>
  );
}